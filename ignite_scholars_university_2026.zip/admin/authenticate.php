<?php
session_start();
require_once "../config/database.php";
$user = trim($_POST['username'] ?? '');
$pass = $_POST['password'] ?? '';
$stmt = $conn->prepare("SELECT id, username, password_hash FROM admins WHERE username=? LIMIT 1");
$stmt->bind_param("s",$user); $stmt->execute(); $result=$stmt->get_result(); $admin=$result->fetch_assoc();
if($admin && password_verify($pass,$admin['password_hash'])) {
    $_SESSION['admin'] = $admin['username'];
    header("Location: dashboard.php"); exit;
}
header("Location: login.php?error=" . urlencode("Invalid username or password.")); exit;