<?php
session_start(); if(!isset($_SESSION['admin'])) { header("Location: login.php"); exit; }
require_once "../config/database.php";
$count = $conn->query("SELECT COUNT(*) c FROM applications")->fetch_assoc()['c'];
$recent = $conn->query("SELECT application_number, first_name, last_name, course, email, created_at FROM applications ORDER BY id DESC LIMIT 10");
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Dashboard</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><header class="site-header"><div class="brand"><div class="logo">ISU</div><div><h1>Admin Dashboard</h1><p>Ignite Scholars University</p></div></div><a class="logout" href="logout.php">Logout</a></header>
<main class="container"><div class="stat"><span>Total Applications</span><b><?=htmlspecialchars($count)?></b></div>
<div class="toolbar"><a class="primary btn" href="applications.php">View All Applications</a></div>
<h2>Recent Applications</h2><div class="table-wrap"><table><tr><th>Application No.</th><th>Name</th><th>Course</th><th>Email</th><th>Date</th></tr>
<?php while($r=$recent->fetch_assoc()): ?><tr><td><a href="view_application.php?id=<?=urlencode($r['application_number'])?>"><?=htmlspecialchars($r['application_number'])?></a></td><td><?=htmlspecialchars($r['first_name'].' '.$r['last_name'])?></td><td><?=htmlspecialchars($r['course'])?></td><td><?=htmlspecialchars($r['email'])?></td><td><?=htmlspecialchars($r['created_at'])?></td></tr><?php endwhile; ?>
</table></div></main></body></html>