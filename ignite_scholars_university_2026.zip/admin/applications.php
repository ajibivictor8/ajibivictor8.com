<?php
session_start(); if(!isset($_SESSION['admin'])) { header("Location: login.php"); exit; }
require_once "../config/database.php";
$q = trim($_GET['q'] ?? '');
if($q !== '') {
  $like="%".$q."%"; $stmt=$conn->prepare("SELECT * FROM applications WHERE application_number LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR course LIKE ? ORDER BY id DESC");
  $stmt->bind_param("sssss",$like,$like,$like,$like,$like); $stmt->execute(); $apps=$stmt->get_result();
} else $apps=$conn->query("SELECT * FROM applications ORDER BY id DESC");
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Applications</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><header class="site-header"><div class="brand"><div class="logo">ISU</div><div><h1>Applications</h1><p>Ignite Scholars University</p></div></div><a class="logout" href="logout.php">Logout</a></header>
<main class="container"><form class="search" method="GET"><input name="q" value="<?=htmlspecialchars($q)?>" placeholder="Search application no., name, email or course"><button class="secondary">Search</button></form>
<div class="table-wrap"><table><tr><th>Application No.</th><th>Name</th><th>Course</th><th>Phone</th><th>Submitted</th><th>Action</th></tr>
<?php while($r=$apps->fetch_assoc()): ?><tr><td><?=htmlspecialchars($r['application_number'])?></td><td><?=htmlspecialchars($r['first_name'].' '.$r['last_name'])?></td><td><?=htmlspecialchars($r['course'])?></td><td><?=htmlspecialchars($r['phone'])?></td><td><?=htmlspecialchars($r['created_at'])?></td><td><a href="view_application.php?id=<?=urlencode($r['application_number'])?>">View / Print</a></td></tr><?php endwhile; ?></table></div></main></body></html>