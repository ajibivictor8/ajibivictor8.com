<?php
session_start();
if(isset($_SESSION['admin'])) { header("Location: dashboard.php"); exit; }
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><main class="login"><h1>Ignite Scholars University</h1><h2>Admin Login</h2>
<?php if($error): ?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="POST" action="authenticate.php">
<label>Username<input name="username" required></label>
<label>Password<input type="password" name="password" required></label>
<button class="primary">Login</button>
</form><p class="hint">Default: admin / admin123 (change it in the database before production use).</p>
</main></body></html>