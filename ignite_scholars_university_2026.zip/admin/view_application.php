<?php
session_start(); if(!isset($_SESSION['admin'])) { header("Location: login.php"); exit; }
require_once "../config/database.php";
$id=$_GET['id'] ?? '';
$stmt=$conn->prepare("SELECT * FROM applications WHERE application_number=? LIMIT 1"); $stmt->bind_param("s",$id); $stmt->execute(); $a=$stmt->get_result()->fetch_assoc();
if(!$a) die("Application not found.");
$results=json_decode($a['olevel_results'],true) ?: [];
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Application <?=$a['application_number']?></title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><main class="container print-card"><div class="application-head"><div class="logo">ISU</div><div><h1>Ignite Scholars University</h1><h2>2026 Application Record</h2><p>Application No: <b><?=htmlspecialchars($a['application_number'])?></b></p></div><img class="passport" src="../uploads/passports/<?=htmlspecialchars($a['passport'])?>" alt="Passport"></div>
<div class="detail-grid">
<?php $fields=['first_name'=>'First Name','middle_name'=>'Middle Name','last_name'=>'Last Name','date_of_birth'=>'Date of Birth','gender'=>'Gender','marital_status'=>'Marital Status','state_of_origin'=>'State of Origin','lga'=>'LGA','course'=>'Course','jamb_number'=>'JAMB Number','jamb_score'=>'JAMB Score','previous_institution'=>'Previous Institution','qualification'=>'Qualification','exam_year'=>'Exam Year','email'=>'Email','phone'=>'Phone','address'=>'Address']; foreach($fields as $k=>$label): ?>
<div><small><?=htmlspecialchars($label)?></small><strong><?=htmlspecialchars($a[$k] ?? '')?></strong></div>
<?php endforeach; ?></div>
<h3>O'Level Results</h3><table><tr><th>Subject</th><th>Grade</th></tr><?php foreach($results as $r): ?><tr><td><?=htmlspecialchars($r['subject'])?></td><td><?=htmlspecialchars($r['grade'])?></td></tr><?php endforeach; ?></table>
<p><small>Submitted: <?=htmlspecialchars($a['created_at'])?></small></p><button class="primary no-print" onclick="window.print()">Print Application</button> <a class="secondary btn no-print" href="applications.php">Back</a>
</main></body></html>