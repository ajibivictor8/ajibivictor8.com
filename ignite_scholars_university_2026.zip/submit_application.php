<?php
require_once "config/database.php";

function fail($message) {
    header("Location: index.php?error=" . urlencode($message));
    exit;
}
function post($key) {
    return trim($_POST[$key] ?? '');
}

$required = ['first_name','last_name','date_of_birth','gender','state_of_origin','lga','course','email','phone','address'];
foreach ($required as $field) {
    if (post($field) === '') fail("Please complete all required fields.");
}
if (!filter_var(post('email'), FILTER_VALIDATE_EMAIL)) fail("Please enter a valid email address.");
if (!isset($_POST['declaration'])) fail("You must accept the declaration.");

if (!isset($_FILES['passport']) || $_FILES['passport']['error'] !== UPLOAD_ERR_OK) fail("Please upload a passport photograph.");
$file = $_FILES['passport'];
if ($file['size'] > 2 * 1024 * 1024) fail("Passport photograph must not exceed 2 MB.");

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($file['tmp_name']);
$allowed = ['image/jpeg'=>'jpg','image/png'=>'png'];
if (!isset($allowed[$mime])) fail("Passport must be a JPG or PNG image.");

$application_number = 'ISU2026' . strtoupper(bin2hex(random_bytes(3)));

$uploadDir = __DIR__ . '/uploads/passports';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
$filename = $application_number . '.' . $allowed[$mime];
if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) fail("Unable to save passport photograph.");

$subjects = $_POST['subjects'] ?? [];
$grades = $_POST['grades'] ?? [];
$results = [];
for ($i=0; $i<count($subjects); $i++) {
    $s = trim($subjects[$i] ?? '');
    $g = trim($grades[$i] ?? '');
    if ($s !== '' || $g !== '') $results[] = ['subject'=>$s, 'grade'=>$g];
}
$results_json = json_encode($results, JSON_UNESCAPED_UNICODE);

$sql = "INSERT INTO applications
(application_number, first_name, middle_name, last_name, date_of_birth, gender, marital_status,
state_of_origin, lga, course, jamb_number, jamb_score, previous_institution, qualification,
exam_year, email, phone, address, olevel_results, passport)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

$stmt = $conn->prepare($sql);
if (!$stmt) fail("Database error. Please contact the administrator.");

$first=post('first_name'); $middle=post('middle_name'); $last=post('last_name');
$dob=post('date_of_birth'); $gender=post('gender'); $marital=post('marital_status');
$state=post('state_of_origin'); $lga=post('lga'); $course=post('course');
$jamb=post('jamb_number'); $jscore=($_POST['jamb_score'] ?? '') === '' ? null : (int)$_POST['jamb_score'];
$previous=post('previous_institution'); $qualification=post('qualification');
$examyear=($_POST['exam_year'] ?? '') === '' ? null : (int)$_POST['exam_year'];
$email=post('email'); $phone=post('phone'); $address=post('address');

$stmt->bind_param("sssssssssssississsss",
    $application_number,$first,$middle,$last,$dob,$gender,$marital,$state,$lga,$course,
    $jamb,$jscore,$previous,$qualification,$examyear,$email,$phone,$address,$results_json,$filename
);

if (!$stmt->execute()) {
    @unlink($uploadDir . '/' . $filename);
    fail("Unable to save application: " . $stmt->error);
}
$stmt->close();
$conn->close();

header("Location: index.php?success=" . urlencode($application_number));
exit;