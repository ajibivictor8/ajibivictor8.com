function addResult(){
 const wrap=document.getElementById('results');
 const row=document.createElement('div');
 row.className='result-row';
 row.innerHTML='<input name="subjects[]" placeholder="Subject"><input name="grades[]" placeholder="Grade"><button type="button" class="remove" onclick="removeRow(this)">×</button>';
 wrap.appendChild(row);
}
function removeRow(btn){
 const rows=document.querySelectorAll('.result-row');
 if(rows.length>1) btn.parentElement.remove();
}
document.getElementById('applicationForm')?.addEventListener('submit',function(e){
 const file=document.querySelector('input[name="passport"]');
 if(file && file.files[0] && file.files[0].size>2*1024*1024){
   e.preventDefault(); alert('Passport photograph must not exceed 2 MB.');
 }
});