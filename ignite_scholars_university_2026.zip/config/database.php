<?php
$host = "localhost";
$dbname = "ignite_university";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed. Import database/ignite_university.sql and check config/database.php.");
}
$conn->set_charset("utf8mb4");