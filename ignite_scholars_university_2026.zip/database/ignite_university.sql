CREATE DATABASE IF NOT EXISTS ignite_university CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ignite_university;

CREATE TABLE IF NOT EXISTS applications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 application_number VARCHAR(30) NOT NULL UNIQUE,
 first_name VARCHAR(100) NOT NULL,
 middle_name VARCHAR(100) DEFAULT NULL,
 last_name VARCHAR(100) NOT NULL,
 date_of_birth DATE NOT NULL,
 gender VARCHAR(20) NOT NULL,
 marital_status VARCHAR(30) DEFAULT NULL,
 state_of_origin VARCHAR(100) NOT NULL,
 lga VARCHAR(100) NOT NULL,
 course VARCHAR(150) NOT NULL,
 jamb_number VARCHAR(50) DEFAULT NULL,
 jamb_score INT DEFAULT NULL,
 previous_institution VARCHAR(200) DEFAULT NULL,
 qualification VARCHAR(50) DEFAULT NULL,
 exam_year INT DEFAULT NULL,
 email VARCHAR(150) NOT NULL,
 phone VARCHAR(30) NOT NULL,
 address TEXT NOT NULL,
 olevel_results JSON DEFAULT NULL,
 passport VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_application_number(application_number),
 INDEX idx_email(email),
 INDEX idx_course(course)
);

CREATE TABLE IF NOT EXISTS admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admins (username,password_hash)
SELECT 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEaP3aB8fT1VJ7q1qQ6Yw8x5k3xK'
WHERE NOT EXISTS (SELECT 1 FROM admins WHERE username='admin');

-- Default password is admin123. Change it before production use.
