<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ignite Scholars University | 2026 Application</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="brand">
    <div class="logo">ISU</div>
    <div><h1>Ignite Scholars University</h1><p>2026 Undergraduate Application Portal</p></div>
  </div>
</header>

<main class="container">
  <section class="hero">
    <h2>2026 Admission Application Form</h2>
    <p>Complete the form carefully. Fields marked <b>*</b> are required.</p>
  </section>

  <?php if(isset($_GET['success'])): ?>
    <div class="alert success">Application submitted successfully. Your application number is <b><?=htmlspecialchars($_GET['success'])?></b>.</div>
  <?php endif; ?>
  <?php if(isset($_GET['error'])): ?>
    <div class="alert error"><?=htmlspecialchars($_GET['error'])?></div>
  <?php endif; ?>

  <form action="submit_application.php" method="POST" enctype="multipart/form-data" id="applicationForm">
    <div class="steps"><span class="active">1. Bio-data</span><span>2. Academic</span><span>3. Contact</span><span>4. Upload</span></div>

    <fieldset>
      <legend>Personal Information</legend>
      <div class="grid">
        <label>First Name *<input name="first_name" required maxlength="100"></label>
        <label>Middle Name<input name="middle_name" maxlength="100"></label>
        <label>Last Name *<input name="last_name" required maxlength="100"></label>
        <label>Date of Birth *<input type="date" name="date_of_birth" required></label>
        <label>Gender *
          <select name="gender" required><option value="">Select</option><option>Male</option><option>Female</option></select>
        </label>
        <label>Marital Status
          <select name="marital_status"><option value="">Select</option><option>Single</option><option>Married</option></select>
        </label>
        <label>State of Origin *<input name="state_of_origin" required></label>
        <label>LGA *<input name="lga" required></label>
      </div>
    </fieldset>

    <fieldset>
      <legend>Programme & Academic Information</legend>
      <div class="grid">
        <label>Programme / Course *
          <select name="course" required>
            <option value="">Select programme</option>
            <option>Computer Science</option><option>Software Engineering</option>
            <option>Accounting</option><option>Business Administration</option>
            <option>Economics</option><option>Mass Communication</option>
            <option>Biology Education</option><option>Geography Education</option>
            <option>Political Science</option><option>Public Administration</option>
          </select>
        </label>
        <label>JAMB Registration Number<input name="jamb_number" maxlength="50"></label>
        <label>JAMB Score<input type="number" name="jamb_score" min="0" max="400"></label>
        <label>Previous Institution<input name="previous_institution"></label>
        <label>Highest Qualification
          <select name="qualification"><option value="">Select</option><option>SSCE</option><option>NECO</option><option>GCE</option><option>Other</option></select>
        </label>
        <label>Exam Year<input type="number" name="exam_year" min="1990" max="2030"></label>
      </div>
    </fieldset>

    <fieldset>
      <legend>Contact Information</legend>
      <div class="grid">
        <label>Email Address *<input type="email" name="email" required maxlength="150"></label>
        <label>Phone Number *<input type="tel" name="phone" required maxlength="30"></label>
        <label class="full">Residential Address *<textarea name="address" required rows="3"></textarea></label>
      </div>
    </fieldset>

    <fieldset>
      <legend>O'Level Results</legend>
      <p class="hint">Enter subjects and grades as applicable. Example: English Language — C6.</p>
      <div id="results">
        <div class="result-row"><input name="subjects[]" placeholder="Subject"><input name="grades[]" placeholder="Grade"><button type="button" class="remove" onclick="removeRow(this)">×</button></div>
      </div>
      <button type="button" class="secondary" onclick="addResult()">+ Add Subject</button>
    </fieldset>

    <fieldset>
      <legend>Passport Photograph</legend>
      <label>Passport Photo *<input type="file" name="passport" accept="image/jpeg,image/png" required></label>
      <p class="hint">JPG or PNG, maximum 2 MB.</p>
    </fieldset>

    <label class="consent"><input type="checkbox" name="declaration" value="1" required> I declare that the information supplied in this application is true and complete.</label>

    <button class="primary" type="submit">Submit Application</button>
  </form>
</main>
<script src="assets/js/app.js"></script>
</body>
</html>