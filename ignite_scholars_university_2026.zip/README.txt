IGNITE SCHOLARS UNIVERSITY - 2026 APPLICATION SYSTEM
======================================================

REQUIREMENTS
- XAMPP (Apache + MySQL) or equivalent PHP/MySQL server
- PHP 8+ recommended
- MySQL/MariaDB

INSTALLATION
1. Copy the "ignite_scholars_university" folder into:
   C:\xampp\htdocs\

2. Start Apache and MySQL from XAMPP Control Panel.

3. Open phpMyAdmin:
   http://localhost/phpmyadmin

4. Import:
   database/ignite_university.sql

5. Confirm config/database.php:
   host=localhost
   dbname=ignite_university
   username=root
   password=

6. Open:
   http://localhost/ignite_scholars_university/

ADMIN
Admin login:
   URL: http://localhost/ignite_scholars_university/admin/login.php
   Username: admin
   Password: admin123

IMPORTANT SECURITY NOTES
- Change the default admin password before deploying publicly.
- Set a strong MySQL password in production.
- Use HTTPS on a live server.
- Restrict the uploads directory and server permissions appropriately.
- This is a starter application system; add CSRF protection, rate limiting,
  email verification and stronger admin/user management before production.

FEATURES
- Applicant registration/application form
- Passport upload (JPG/PNG, max 2 MB)
- O'Level subject/grade entries
- MySQL storage
- Unique application number
- Admin login
- Application search
- Application details
- Print-ready application record
